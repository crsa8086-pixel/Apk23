package com.mineear.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.Process
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.mineear.app.dsp.HearingDspChain
import kotlin.concurrent.thread
import kotlin.math.abs

/**
 * خدمة أمامية (Foreground Service) تُشغّل حلقة الصوت الحقيقية:
 * ميكروفون → معالجة DSP → سماعة، باستمرار وبأقل تأخير ممكن،
 * حتى عندما تكون الشاشة مطفأة أو التطبيق في الخلفية.
 */
class HearingService : Service() {

    companion object {
        const val CHANNEL_ID = "hearing_service_channel"
        const val NOTIF_ID = 1
        const val ACTION_STOP = "com.mineear.app.STOP"

        @Volatile var isRunning = false
        @Volatile var currentGain = 3.0
        @Volatile var currentSensitivity = 0.5
        @Volatile var requestCalibration = false
        @Volatile var lastInputLevel = 0f // لعداد المستوى في الواجهة (0..1 تقريباً)
    }

    @Volatile private var keepRunning = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            keepRunning = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, buildNotification())
        startAudioLoop()
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val mgr = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "مكبّر السمع", NotificationManager.IMPORTANCE_LOW
            )
            mgr?.createNotificationChannel(channel)
        }

        val stopIntent = Intent(this, HearingService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("مكبّر السمع يعمل الآن")
            .setContentText("يتم تضخيم الأصوات وتصفية الضجيج")
            .setSmallIcon(R.drawable.ic_notification)
            .addAction(0, "إيقاف", stopPending)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun startAudioLoop() {
        if (keepRunning) return
        keepRunning = true
        isRunning = true
        thread(start = true, priority = Process.THREAD_PRIORITY_URGENT_AUDIO) { runAudioLoop() }
    }

    private fun runAudioLoop() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            keepRunning = false
            isRunning = false
            return
        }

        val sampleRate = AudioTrack.getNativeOutputSampleRate(AudioManager.STREAM_MUSIC)
            .takeIf { it > 0 } ?: 44100

        val minBufIn = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(2048)
        val minBufOut = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(2048)

        val audioSource = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            MediaRecorder.AudioSource.UNPROCESSED
        } else {
            MediaRecorder.AudioSource.MIC
        }

        var recorder = try {
            AudioRecord(
                audioSource, sampleRate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, minBufIn * 2
            )
        } catch (e: Exception) {
            null
        }
        if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder?.release()
            recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, minBufIn * 2
            )
        }
        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            keepRunning = false
            isRunning = false
            recorder.release()
            return
        }

        // USAGE_ASSISTANCE_ACCESSIBILITY: هو الوصف الدلالي الصحيح لتطبيق "مساعدة سمعية"
        // (مثل أدوات قراءة الشاشة)، ويضمن توجيهاً طبيعياً للمخرج (سماعة/مكبر رئيسي).
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minBufOut * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        val dsp = HearingDspChain(sampleRate.toFloat())
        val blockSize = 256
        val inBuf = ShortArray(blockSize)
        val outBuf = ShortArray(blockSize)

        try {
            recorder.startRecording()
            track.play()

            while (keepRunning) {
                dsp.gainLinear = currentGain
                dsp.noiseGate.sensitivity = currentSensitivity

                if (requestCalibration) {
                    dsp.noiseGate.calibrating = true
                    Thread.sleep(1500)
                    dsp.noiseGate.calibrating = false
                    requestCalibration = false
                }

                val read = recorder.read(inBuf, 0, blockSize)
                if (read > 0) {
                    dsp.processBuffer(inBuf, outBuf, read)
                    track.write(outBuf, 0, read)

                    var peak = 0
                    for (i in 0 until read) {
                        val v = abs(inBuf[i].toInt())
                        if (v > peak) peak = v
                    }
                    lastInputLevel = peak / 32768f
                }
            }
        } catch (_: Exception) {
            // تجاهل صامت؛ الحلقة ستتوقف وسيتم تحرير الموارد في finally
        } finally {
            try { recorder.stop() } catch (_: Exception) {}
            try { recorder.release() } catch (_: Exception) {}
            try { track.stop() } catch (_: Exception) {}
            try { track.release() } catch (_: Exception) {}
            isRunning = false
        }
    }

    override fun onDestroy() {
        keepRunning = false
        isRunning = false
        super.onDestroy()
    }
}
