package com.mineear.app.dsp

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * مرشّح صوتي من الدرجة الثانية (Biquad) مبني على معادلات "Audio EQ Cookbook"
 * المعروفة (Robert Bristow-Johnson). يُستخدم هنا لغرضين:
 *  1) تمرير عالي (High-pass) لحذف الترددات المنخفضة جداً — وهي غالباً مصدر
 *     دمدمة الآلات والمعدات الثقيلة في المنجم.
 *  2) تعزيز انتقائي (Peaking) حول نطاق تردد الصوت البشري لزيادة الوضوح.
 */
class BiquadFilter {
    private var b0 = 1.0
    private var b1 = 0.0
    private var b2 = 0.0
    private var a1 = 0.0
    private var a2 = 0.0

    // ذاكرة العينات والمخرجات السابقة
    private var x1 = 0.0
    private var x2 = 0.0
    private var y1 = 0.0
    private var y2 = 0.0

    fun setHighPass(sampleRate: Float, cutoffHz: Float, q: Float = 0.707f) {
        val w0 = 2.0 * PI * cutoffHz / sampleRate
        val alpha = sin(w0) / (2.0 * q)
        val cosw0 = cos(w0)

        val b0n = (1 + cosw0) / 2.0
        val b1n = -(1 + cosw0)
        val b2n = (1 + cosw0) / 2.0
        val a0n = 1 + alpha
        val a1n = -2 * cosw0
        val a2n = 1 - alpha

        normalize(b0n, b1n, b2n, a0n, a1n, a2n)
    }

    fun setPeaking(sampleRate: Float, centerHz: Float, gainDb: Float, q: Float = 1.0f) {
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = 2.0 * PI * centerHz / sampleRate
        val alpha = sin(w0) / (2.0 * q)
        val cosw0 = cos(w0)

        val b0n = 1 + alpha * a
        val b1n = -2 * cosw0
        val b2n = 1 - alpha * a
        val a0n = 1 + alpha / a
        val a1n = -2 * cosw0
        val a2n = 1 - alpha / a

        normalize(b0n, b1n, b2n, a0n, a1n, a2n)
    }

    private fun normalize(b0n: Double, b1n: Double, b2n: Double, a0n: Double, a1n: Double, a2n: Double) {
        b0 = b0n / a0n
        b1 = b1n / a0n
        b2 = b2n / a0n
        a1 = a1n / a0n
        a2 = a2n / a0n
    }

    fun process(input: Double): Double {
        val output = b0 * input + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1; x1 = input
        y2 = y1; y1 = output
        return output
    }
}
