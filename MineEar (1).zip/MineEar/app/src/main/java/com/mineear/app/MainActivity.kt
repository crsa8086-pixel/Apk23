package com.mineear.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                HearingScreen()
            }
        }
    }

    @Composable
    fun HearingScreen() {
        var hasRecordPermission by remember {
            mutableStateOf(
                ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED
            )
        }

        val permissionsNeeded = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        val permissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { results ->
            hasRecordPermission = results[Manifest.permission.RECORD_AUDIO] == true
        }

        var running by remember { mutableStateOf(HearingService.isRunning) }
        var gain by remember { mutableStateOf(3f) }
        var sensitivity by remember { mutableStateOf(0.5f) }
        var level by remember { mutableStateOf(0f) }
        var headsetConnected by remember { mutableStateOf(isHeadsetConnected()) }

        LaunchedEffect(Unit) {
            while (true) {
                delay(150)
                level = HearingService.lastInputLevel
                running = HearingService.isRunning
                headsetConnected = isHeadsetConnected()
            }
        }

        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0B0F10)) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(16.dp))
                Text(
                    "مكبّر السمع",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    "للاستخدام الشخصي في بيئة العمل تحت الأرض",
                    fontSize = 13.sp,
                    color = Color.Gray
                )

                Spacer(Modifier.height(16.dp))

                if (!headsetConnected) {
                    Surface(
                        color = Color(0xFF3A2A00),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "⚠ يُفضَّل استخدام سماعة أذن سلكية لتفادي الصدى (التغذية الراجعة) بين الميكروفون والسماعة",
                            color = Color(0xFFFFD54F),
                            modifier = Modifier.padding(12.dp),
                            fontSize = 13.sp
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                }

                Text("مستوى الصوت الملتقط", color = Color.Gray, fontSize = 12.sp)
                LinearProgressIndicator(
                    progress = level.coerceIn(0f, 1f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp),
                    color = if (level > 0.9f) Color(0xFFE53935) else Color(0xFF4CAF50)
                )

                Spacer(Modifier.height(32.dp))

                Button(
                    onClick = {
                        if (!hasRecordPermission) {
                            permissionLauncher.launch(permissionsNeeded.toTypedArray())
                            return@Button
                        }
                        val intent = Intent(this@MainActivity, HearingService::class.java)
                        if (running) {
                            intent.action = HearingService.ACTION_STOP
                            startService(intent)
                        } else {
                            ContextCompat.startForegroundService(this@MainActivity, intent)
                        }
                    },
                    modifier = Modifier.size(160.dp),
                    shape = RoundedCornerShape(80.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (running) Color(0xFFC62828) else Color(0xFF2E7D32)
                    )
                ) {
                    Text(
                        if (running) "إيقاف" else "تشغيل",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(Modifier.height(40.dp))

                Text("التضخيم: ${"%.1f".format(gain)}x", color = Color.White, fontSize = 16.sp)
                Slider(
                    value = gain,
                    onValueChange = {
                        gain = it
                        HearingService.currentGain = it.toDouble()
                    },
                    valueRange = 1f..8f
                )

                Spacer(Modifier.height(16.dp))

                Text(
                    "حساسية تصفية ضجيج الخلفية: ${(sensitivity * 100).toInt()}%",
                    color = Color.White,
                    fontSize = 16.sp
                )
                Slider(
                    value = sensitivity,
                    onValueChange = {
                        sensitivity = it
                        HearingService.currentSensitivity = it.toDouble()
                    },
                    valueRange = 0f..1f
                )

                Spacer(Modifier.height(24.dp))

                OutlinedButton(
                    onClick = { HearingService.requestCalibration = true },
                    enabled = running
                ) {
                    Text("معايرة ضجيج المكان الحالي (ثانيتان)")
                }

                Spacer(Modifier.weight(1f))

                Text(
                    "ملاحظة: هذا التطبيق أداة مساعدة للسمع وليس بديلاً عن معدات " +
                        "السلامة المعتمدة في المنجم (كاشف الغاز، أنظمة الإنذار الرسمية). " +
                        "التزم دوماً بإجراءات السلامة، وارفع مستوى الصوت تدريجياً تجنباً لإجهاد السمع.",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    private fun isHeadsetConnected(): Boolean {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        return devices.any {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
    }
}
