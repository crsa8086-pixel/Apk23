package com.mineear.app.dsp

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.pow

/**
 * بوابة ضجيج تكيّفية (Adaptive Noise Gate).
 *
 * الفكرة: نتتبّع "أرضية الضجيج" المحيط (مستوى الضجيج الثابت المستمر، كصوت
 * الآلات أو التهوية) بشكل بطيء جداً، ثم نُخفّض أي إشارة قريبة من تلك الأرضية
 * بسلاسة (بدون قطع مفاجئ يسبب "تكسير" في الصوت)، بينما نترك الأصوات الأعلى
 * من الأرضية (نداء، صرير، إنذار) تمر بحرية لتُضخَّم لاحقاً.
 *
 * هذا ليس حذفاً تاماً للضجيج (ذلك يتطلب تحليل طيفي FFT كامل)، لكنه عملي
 * وفعّال وخفيف الحمل الحاسوبي، وهو ما يحتاجه تطبيق يعمل في الزمن الحقيقي
 * على هاتف محمول.
 */
class AdaptiveNoiseGate(private val sampleRate: Float) {

    private var noiseFloor = 0.003   // تقدير أولي لمستوى RMS للضجيج المحيط
    private var envelope = 0.0       // مغلّف الإشارة الحالي
    private var gateGain = 1.0       // الكسب الحالي للبوابة (0..1)

    private val floorTrack = timeToCoeff(2.5f)   // تتبّع بطيء جداً لأرضية الضجيج
    private val envAttack = timeToCoeff(0.005f)  // فتح سريع عند صوت مفاجئ
    private val envRelease = timeToCoeff(0.25f)  // إغلاق تدريجي ناعم

    /** حساسية التصفية من 0 (معطّلة تقريباً) إلى 1 (أقوى تصفية) — تُضبط من الواجهة */
    var sensitivity = 0.5

    @Volatile
    var calibrating = false

    private fun timeToCoeff(seconds: Float): Double =
        exp(-1.0 / (seconds * sampleRate))

    fun process(input: Double): Double {
        val rectified = abs(input)

        envelope = if (rectified > envelope) {
            envAttack * envelope + (1 - envAttack) * rectified
        } else {
            envRelease * envelope + (1 - envRelease) * rectified
        }

        if (calibrating) {
            // أثناء المعايرة: اجعل الأرضية تتبع المغلّف مباشرة وبسرعة
            noiseFloor = 0.95 * noiseFloor + 0.05 * envelope
        } else if (envelope < noiseFloor * 1.5) {
            // تحديث بطيء جداً حتى لا "تبتلع" البوابة صوتاً حقيقياً طويل الأمد
            noiseFloor = floorTrack * noiseFloor + (1 - floorTrack) * envelope
        }

        val threshold = noiseFloor * (1.0 + sensitivity * 6.0)
        val targetGain = if (envelope > threshold) {
            1.0
        } else {
            (envelope / threshold).coerceIn(0.0001, 1.0).pow(2.0)
        }

        gateGain = if (targetGain > gateGain) {
            envAttack * gateGain + (1 - envAttack) * targetGain
        } else {
            envRelease * gateGain + (1 - envRelease) * targetGain
        }

        return input * gateGain
    }
}
