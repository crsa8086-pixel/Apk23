package com.mineear.app.dsp

import kotlin.math.tanh

/**
 * محدّد ناعم (Soft Limiter) باستخدام دالة tanh.
 * يمنع التشويه الحاد (hard clipping) عند رفع التضخيم بقوة على صوت مفاجئ وعالٍ،
 * ويحمي الأذن من قمم صوتية حادة غير متوقعة أثناء الاستخدام بسماعات الأذن.
 */
class SoftLimiter(private val ceiling: Double = 0.9) {
    fun process(input: Double): Double = ceiling * tanh(input / ceiling)
}
