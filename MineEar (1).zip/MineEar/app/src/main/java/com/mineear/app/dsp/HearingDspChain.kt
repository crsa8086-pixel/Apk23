package com.mineear.app.dsp

/**
 * سلسلة المعالجة الكاملة لكل عيّنة صوتية، بالترتيب:
 *   1) تمرير عالٍ لحذف دمدمة الآلات منخفضة التردد (أسفل ~150Hz)
 *   2) تعزيز خفيف حول نطاق وضوح الصوت البشري (~2200Hz) لزيادة الفهم
 *   3) تضخيم (Gain) قابل للتعديل من المستخدم
 *   4) بوابة ضجيج تكيّفية تُخفّض الضجيج الثابت المحيط
 *   5) محدّد ناعم يحمي من التشويه والقمم الصوتية المفاجئة
 *
 * القيم الافتراضية مُحافِظة عمداً (سقف تضخيم وحدّ أقصى للصوت) لتقليل خطر
 * إجهاد السمع عند استخدام سماعات الأذن لفترات طويلة في بيئة عمل.
 */
class HearingDspChain(sampleRate: Float) {

    private val highPass = BiquadFilter().apply { setHighPass(sampleRate, 150f) }
    private val voiceBoost = BiquadFilter().apply { setPeaking(sampleRate, 2200f, 6f, 1.0f) }
    val noiseGate = AdaptiveNoiseGate(sampleRate)
    private val limiter = SoftLimiter(ceiling = 0.9)

    /** مجال مقترح من الواجهة: 1.0 (بدون تضخيم) إلى 8.0 */
    @Volatile
    var gainLinear = 3.0

    private fun processSample(inputSample: Double): Double {
        var s = highPass.process(inputSample)
        s = voiceBoost.process(s)
        s *= gainLinear
        s = noiseGate.process(s)
        s = limiter.process(s)
        return s
    }

    fun processBuffer(input: ShortArray, output: ShortArray, len: Int) {
        for (i in 0 until len) {
            val sample = input[i] / 32768.0
            val processed = processSample(sample)
            val clamped = (processed * 32767.0).toInt().coerceIn(-32768, 32767)
            output[i] = clamped.toShort()
        }
    }
}
